<?php
/**
 * User: Xunm
 * Date: 2018/10/17
 * Time: 1:18
 */
return [
    'admin/Index/index',
    'admin/Home/index',
];
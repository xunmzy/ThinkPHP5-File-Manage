<?php
/**
 * User: Xunm
 * Date: 2018/10/15
 * Time: 0:07
 */

return [
    'admin_password_only_id' => '_~!^&admin_xunmzy"{}#$~^-',// 作为管理员的密码的掩码
    'user_password_only_id' => '_~!^&user_xunmzy"{}#$~^-',// 作为注册会员的密码的掩码
];
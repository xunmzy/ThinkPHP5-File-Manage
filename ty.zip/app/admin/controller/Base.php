<?php
/**
 * User: Xunm
 * Date: 2018/10/10
 * Time: 1:01
 */

namespace app\admin\controller;


use think\Controller;

class Base extends Controller
{
}

<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:50:"/data/www/public/../app/admin/view/home/index.html";i:1539378628;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
啥也没有，看啥看，起开！！！
</body>
</html>
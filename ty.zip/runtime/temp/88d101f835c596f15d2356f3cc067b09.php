<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:51:"/data/www/public/../app/index/view/index/index.html";i:1539392716;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
46549798789
</body>
</html>